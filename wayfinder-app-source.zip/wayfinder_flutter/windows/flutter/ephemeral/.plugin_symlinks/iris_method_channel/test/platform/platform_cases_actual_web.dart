void platformCases() {
  // Empty
}
